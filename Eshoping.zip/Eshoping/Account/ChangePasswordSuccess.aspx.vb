﻿
Partial Class Account_ChangePasswordSuccess
    Inherits System.Web.UI.Page

End Class
