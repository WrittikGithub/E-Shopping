﻿
Partial Class Admin_product_search
    Inherits System.Web.UI.Page

End Class
