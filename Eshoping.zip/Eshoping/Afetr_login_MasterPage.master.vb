﻿
Partial Class Afetr_login_MasterPage
    Inherits System.Web.UI.MasterPage
End Class

