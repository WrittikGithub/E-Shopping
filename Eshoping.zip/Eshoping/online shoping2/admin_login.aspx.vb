﻿
Partial Class admin_login
    Inherits System.Web.UI.Page

End Class
