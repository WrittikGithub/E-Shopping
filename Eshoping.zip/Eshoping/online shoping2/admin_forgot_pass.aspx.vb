﻿
Partial Class admin_forgot_pass
    Inherits System.Web.UI.Page

End Class
