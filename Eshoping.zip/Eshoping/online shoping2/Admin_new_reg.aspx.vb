﻿
Partial Class Admin_new_reg
    Inherits System.Web.UI.Page

End Class
