﻿
Partial Class Customer_new_reg
    Inherits System.Web.UI.Page

End Class
