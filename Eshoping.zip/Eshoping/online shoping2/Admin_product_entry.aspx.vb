﻿
Partial Class Admin_product_entry
    Inherits System.Web.UI.Page

End Class
