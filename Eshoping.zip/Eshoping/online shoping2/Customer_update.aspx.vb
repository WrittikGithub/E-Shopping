﻿
Partial Class Customer_update
    Inherits System.Web.UI.Page

End Class
