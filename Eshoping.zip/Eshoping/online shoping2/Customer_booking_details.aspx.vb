﻿
Partial Class Customer_booking_details
    Inherits System.Web.UI.Page

End Class
