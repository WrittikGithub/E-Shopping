﻿
Partial Class Customer_product_search
    Inherits System.Web.UI.Page

End Class
