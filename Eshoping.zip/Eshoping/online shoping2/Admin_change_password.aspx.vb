﻿
Partial Class Admin_change_password
    Inherits System.Web.UI.Page

End Class
