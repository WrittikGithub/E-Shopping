﻿
Partial Class Bill_print
    Inherits System.Web.UI.Page

End Class
