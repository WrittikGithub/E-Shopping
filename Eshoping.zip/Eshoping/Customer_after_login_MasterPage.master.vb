﻿
Partial Class Customer_after_login_MasterPage
    Inherits System.Web.UI.MasterPage
End Class

