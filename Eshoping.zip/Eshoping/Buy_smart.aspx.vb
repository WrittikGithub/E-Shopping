﻿
Partial Class Buy_smart
    Inherits System.Web.UI.Page

End Class
