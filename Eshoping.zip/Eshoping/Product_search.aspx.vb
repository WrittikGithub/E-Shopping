﻿
Partial Class Product_search
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Literal1.Text = "<marquee direction=left>If you  login then Purchase any product </marquee>"
    End Sub
End Class
